# NAWA (নাওয়া) Landing Page

Final static landing page for the নাওয়া women's fashion brand.

- `index.html` is the complete, self-contained page (fonts and images are embedded), so it can be served as-is, for example with GitHub Pages.
- `assets/images/` holds the three outfit photos as used on the page.
- `assets/fonts/` holds the subset web fonts (Li Alinur for headlines and logo, Adorsho Lipi for body text).
- `preview/` holds a PDF preview of the page.
